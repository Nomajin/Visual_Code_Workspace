const usuario = {
  nombre: "Ana García",
  rol: "Desarrolladora Fullstack",
  foto: "https://randomuser.me",
  habilidades: ["JavaScript", "HTML5", "CSS3", "Node.js", "Git"],
  disponible: true
};
